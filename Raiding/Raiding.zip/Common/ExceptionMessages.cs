﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Common
{
    public class ExceptionMessages
    {
        public const string InvalideHero = "Invalide hero!";
    }
}
