﻿
namespace Raiding.Models.Contracts
{
    public interface IDruid : IHero
    {

    }
}
