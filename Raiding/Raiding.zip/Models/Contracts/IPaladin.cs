﻿
namespace Raiding.Models.Contracts
{
    public interface IPaladin : IHero
    {
    }
}
