﻿
namespace Raiding.Models.Contracts
{
    public interface IWarrior : IHero
    {
    }
}
