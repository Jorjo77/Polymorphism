﻿
namespace Raiding.Models.Contracts
{
    public interface IRogue : IHero
    {
    }
}
