﻿
namespace Raiding.Core
{
    public interface IEngine
    {
        public void Run();
    }
}
