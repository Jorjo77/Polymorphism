﻿
namespace WildFarm.Models.Animals.Contracts
{
    public interface ISoundProduceble
    {
        public string ProduceSound();
    }
}
